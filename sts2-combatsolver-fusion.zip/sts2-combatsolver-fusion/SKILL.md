---
name: sts2-combatsolver-fusion
description: 把 Torch1230 的《杀戮尖塔2》CombatSolver（战斗路线求解器）作为 third_party 子工程融合进 AutoPilot 仓库，并剔除其 UI 浮层、固定求解策略档（中等速度/60秒/零战损优先）。当需要升级 CombatSolver 上游版本、重新应用 UI 剔除补丁、调试其战斗搜索失败（SEARCH_SETUP_FAILURE/NullReferenceException）、或首次做同仓双工程融合时使用。
agent_created: true
---

# StS2 CombatSolver 融合与 UI 剔除

## 用途

把 CombatSolver（第三方 Beam Search 战斗求解器）**作为独立子工程**并入 AutoPilot 仓库，
一次构建、一次部署，但对玩家**不显示任何 UI 浮层**，且采用**固定策略档**。

适用场景：
- 升级 CombatSolver 上游版本后需**重新打 UI 剔除补丁**
- 诊断战斗求解**完全失效**（日志出现 `SEARCH_SETUP_FAILURE` / `NullReferenceException`）
- 首次把某个第三方 mod 源码融合进本仓库

## 关键路径（本机）

| 项 | 路径 |
|---|---|
| 融合子工程 | `D:\尖塔模组\AutoPilot\third_party\CombatSolver\` |
| UI 改造点 | `.../src/UI/SolverOverlay.cs` |
| 策略改造点 | `.../src/Runtime/SolverSettings.cs` |
| 批量插 guard 脚本 | `D:\尖塔模组\patch_overlay_guards.py` |
| 构建 | `python D:\尖塔模组\build_all.py [solver\|autopilot]` |
| 部署 | `python D:\尖塔模组\deploy_autopilot.py` |
| 说明文档 | `D:\尖塔模组\AutoPilot-融合CombatSolver说明.md` |
| 日志 | `%APPDATA%\SlayTheSpire2\logs\CombatSolver\<PID>-<hash>\combat-<hash>.jsonl` |
| 设置 | `%APPDATA%\SlayTheSpire2\combat_solver_settings.json` |

## 为什么必须"双工程"而非合并单 dll

CombatSolver 的 700+ 源文件依赖**编译期**特性：
- `Krafs.Publicizer` + `<Publicize Include="sts2">` → 公开化 sts2.dll 内部成员
- `Godot.NET.Sdk/4.5.1`（AutoPilot 用 `Microsoft.NET.Sdk`）
- `STS2-RitsuLib`

合并会让 Publicize 污染 AutoPilot 整个程序集 → 必须工程隔离。

⚠️ **必须的排除规则**（写在 `AutoPilot.csproj`，否则隐式 glob 吞掉 700+ 文件 → 数百个编译错误）：
```xml
<ItemGroup>
  <Compile Remove="third_party\**\*.cs" />
  <Compile Remove="third_party/**/*.cs" />
  <None Remove="third_party\**\*" />
  <EmbeddedResource Remove="third_party\**\*" />
</ItemGroup>
```

## 改造 1：剔除 UI（核心）

`SolverOverlay.cs`：
1. 加总开关：`internal static bool UiSuppressed { get; set; } = true;`
2. `EnsureCreated(host)` 首行：`if (UiSuppressed) { _layer = null; return; }`
3. `ShowLayer()` 首行：`if (UiSuppressed) return;`
4. 🚨 **给全部公开/内部入口方法首行加短路**（`Show*` / `Refresh*` / `Apply*` / `Hide`，共 ~23 个）：
   ```csharp
   // 【AutoPilot 融合改造】UI 已剔除：入口短路，仅保留引擎调用语义。
   if (UiSuppressed)
   {
       return;
   }
   ```

### 🚨 为什么必须给每个入口都加（血泪）

只改 `EnsureCreated` 是**不够的**：`ShowSearching` 内部有**无 null 检查**的解引用
（`RouteRows[index].TurnLabel.Text = ...`，同类共 12+ 处）。`_layer=null` 时 `RouteRows[0]=null` → NRE，
异常沿 `ShowSearching` → `SolverController.RequestSearch` 抛出 →
```
SEARCH_SETUP_FAILURE stage=combat_root_snapshot reason=AutoTurnStart
exception=System.NullReferenceException
```
→ **所有战斗搜索全部失败，求解器完全瘫痪**（不是"窗口没了但还在算"，而是**完全不算**）。

用 `patch_overlay_guards.py` 批量插入（正则匹配 `    public static ... Name(` 后首个 `    {`）。
升级上游后**必须重跑一次**。

### 不要动的东西
- `SolverDispatcher` —— 它是**主线程调度器**，不是 UI
- `SolverHudButton` —— 死代码

## 改造 2：固定策略档

`SolverSettings.cs` 新增：
```csharp
private static SolverSettingsData ApplyAutoPilotFusionDefaults(SolverSettingsData data)
    => data with
    {
        PerformancePreset = SolverPerformancePreset.Medium,   // BeamWidth 60 / nodes 120000
        SearchTimeLimitSeconds = 60d,
        ActTransitionBossHpStrategy = BossHpStrategy.MinimizeHpLoss,
        FinalBossHpStrategy = BossHpStrategy.MinimizeHpLoss,
        AcceptableBattleHpLoss = 0,
        StopAtAcceptableBattleHpLoss = true,   // 找到零战损路线立即停止；否则由 SoldHpPenalty 选最低战损
    };
```
- `CreateCurrentDefaults()` → `ApplyAutoPilotFusionDefaults(ApplyCurrentPerformanceMigration(new SolverSettingsData()))`
- ⚠️ **`Load()` 里也必须套用**：`migrated = ApplyAutoPilotFusionDefaults(migrated);`（在 `ApplyCurrentPerformanceMigration` 之后）
  —— 否则磁盘上已存在的 `combat_solver_settings.json` 会覆盖默认值（实测旧文件 120s / ProgressionFirst）

## 桥接（AutoPilot 侧，通常零改动）

`AutoPilot/src/SolverBridge.cs` 用**运行时反射**调 `CombatSolver.SolverController.SetFullAuto(NGame, CombatState, bool)`。
`SolverController` 是 `internal static partial class`，不能编译期引用，但成员是 public。
⚠️ 探测必须**惰性 + 可成功才锁**（Init 早于 CombatSolver 加载）。

## 构建与部署

```bash
export DOTNET_ROOT="D:/尖塔模组/.tools/dotnet9"
python build_all.py solver        # 只建 CombatSolver 验证
python build_all.py               # 两个都建
python deploy_autopilot.py        # 停游戏 + 拷两个 mod + MD5 校验
```

⚠️ 部署前**必须停游戏**（dll 被独占锁）；用 Win32 `DeleteFileW`+`CopyFileW`（本机 `os.remove` 被劫持）。

## 验证清单

1. **DLL 含新代码**（.NET 元数据 `#Strings` 堆是 **UTF-8 + NUL**）：
   ```python
   d = open(dll,'rb').read()
   print(d.count(b'get_UiSuppressed'), d.count(b'ApplyAutoPilotFusionDefaults'))
   ```
2. **设置被强制覆写**：游戏跑过一次后 `combat_solver_settings.json` 的
   `searchTimeLimitSeconds` 应为 `60`、`*_boss_hp_strategy` 应为 `MinimizeHpLoss`
3. **战斗日志无失败**：`combat-*.jsonl` 里
   - `SEARCH_SETUP_FAILURE` == 0，`NullReferenceException` == 0
   - `ROUTE_ACTION` > 0（求解器确实在出路线）
4. **窗口消失**：开战截图无任何浮层/面板

## 启动游戏（本机实测）

```powershell
Start-Process 'E:\steam\steam.exe' -ArgumentList '-applaunch 2868840'   # 单参数形式，有效
Start-Process 'steam://rungameid/2868840'                               # 备用
```
无效：两参数形式 `'-applaunch','2868840'`；直接启动 `SlayTheSpire2.exe`。

## 常见故障

| 症状 | 原因 | 处理 |
|---|---|---|
| 构建 280 错误（缺 `STS2RitsuLib`/unsafe） | `AutoPilot.csproj` 缺 third_party 排除 | 加四条 `<Compile Remove>` |
| 战斗全败（`SEARCH_SETUP_FAILURE`） | 只短路了 `EnsureCreated` | 给全部入口加 `UiSuppressed` 短路 |
| 策略档不生效（仍 120s） | `Load()` 没套用融合默认值 | 在 `Load()` 里也调 `ApplyAutoPilotFusionDefaults` |
| CombatSolver 不加载 | RitsuLib 被禁用 | 启用 `STS2-RitsuLib` 0.6.0+ |
| 部署 `ERROR_ACCESS_DENIED=5` | 游戏在运行 | 先 `Stop-Process -Force` |

## 参考

详细流程与踩坑记录见 `references/fusion-notes.md`。
