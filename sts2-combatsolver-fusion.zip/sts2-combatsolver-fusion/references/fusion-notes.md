# 融合踩坑与实测记录

## 时间线（2026-09-26 ~ 09-27）

1. **v2.8.0**：AutoPilot 通过运行时反射 `SolverBridge` 委托外部安装的 CombatSolver v0.46.4
2. **v2.9.0**：用户要求**直接融进本仓库** → 源码迁入 `third_party/CombatSolver/`（双工程）
3. **v2.9.0 收尾**：用户要求**去掉窗口** + 固定**中等速度 / 60 秒 / 零战损优先**

## 坑 1：`Microsoft.NET.Sdk` 隐式 glob 吞掉 third_party → 280 错误

**症状**（`build_all.py autopilot`）：
```
CS0246: 未能找到类型或命名空间名 "STS2RitsuLib"
CS0227: 不安全代码只会在使用 /unsafe 编译时出现
SYSLIB1062
```
共 **280 个错误**。

**根因**：`Microsoft.NET.Sdk` 的隐式 `Compile` glob（`**/*.cs`）**递归**包含了
`third_party/CombatSolver/src/**/*.cs`（700+ 文件），而这些文件依赖 Publicizer/RitsuLib/unsafe。

**修复**：`AutoPilot.csproj` 加四条排除（见 SKILL.md）。

## 坑 2（最严重）：UI 剔除导致**战斗求解完全瘫痪**

**第一次尝试**：只在 `EnsureCreated` / `ShowLayer` 加短路（`_layer = null`）。

**症状**：实机开战，`combat-*.jsonl` **2MB 全是同一个异常**：
```
[CombatSolver/Test] SEARCH_SETUP_FAILURE stage=combat_root_snapshot reason=AutoTurnStart
exception=System.NullReferenceException: Object reference not set to an instance of an object.
   at CombatSolver.SolverOverlay.ShowSearching(Node host, Int32 turn, Boolean deployWhenReady,
        Int64 reviewedWorldlinesBeforeSearch, PotionRewardOutlook potionRewardOutlook)
   at CombatSolver.SolverController.RequestSearch(NGame host, CombatState state, SearchReason reason,
        Boolean deployWhenReady)
```
统计：`SEARCH_SETUP_FAILURE` 数百，`ROUTE_ACTION` **0**。

**根因定位**：`SolverOverlay.ShowSearching` 内（原文件 1045-1053 行）：
```csharp
for (int index = 0; index < SolverWeights.UiTurnRows; index++)
{
    SetRouteRowVisible(index, index == 0);      // ← 这个是 null-safe
    if (index != 0) continue;
    RouteRows[index].TurnLabel.Text = ...;      // ← 无 null 检查！
    RouteRows[index].ShowStatus(...);
    RouteRows[index].SetOutcome(...);
}
```
`RouteRows` 只在 `Create()`（被 `EnsureCreated` 短路跳过）里填充 → `RouteRows[0]` 恒 null。
同类**无保护**的 `RouteRows[...]` 解引用共 **12+ 处**：
`1050-52`、`1200-12`、`1271-79`、`1294`、`1313`。

**为什么不能逐个补 null 检查**：12+ 处 + 以后上游可能加更多 → 太脆。

**正确修复**：把短路提升到**入口边界** —— 给 `SolverOverlay` 全部 23 个
公开/内部入口方法首行加 `if (UiSuppressed) { return; }`。
这样引擎无论怎么调、调到哪个入口，都只得到"无害空操作"。

用 `scripts/patch_overlay_guards.py` 批量处理（幂等逻辑：按签名行 + 首个 `    {` 定位）。
覆盖的 23 个方法：
`Show`、`ShowDisabled`、`ShowSearchStopped`、`ShowManualCalculationReady`、`ShowRetainedRoute`、
`ShowPotionRewardSettingChanged`、`ShowProgress`、`ShowSearching`、`ShowResult`、`ShowDeploying`、
`ShowDeploymentStep`、`ShowEndTurnDeploymentStep`、`ShowDeploymentComplete`、`ShowWaitingForNextTurnPlan`、
`ShowFullAutoStoppedAtCombatEnd`、`ShowFullAutoStoppedAtDeathTurn`、`ShowFullAutoStoppedAfterWorseRecalculation`、
`ShowFullAutoStoppedAtLiveRisk`、`RefreshControls`、`RefreshBossHpStrategyHint`、`RefreshGuidanceHints`、
`Hide`、`ApplyOverlayOpacity`、`ApplyConfiguredTheme`

### ✅ 修复前后对比（实机同机型同战斗）

| 指标 | 修复前 | 修复后 |
|---|---|---|
| `SEARCH_SETUP_FAILURE` | 数百 | **0** |
| `NullReferenceException` | 数百 | **0** |
| `ROUTE_ACTION` | 0 | **94 / 70 / …** |
| `ROUTE_HEALTH` | 0 | **50** |
| DLL md5 / 大小 | `ea085e7cbef2` / 6424064 | `e50fad6af9f2` / 6424576 |

修复后求解器输出完整跨回合路线，且**会按敌人死亡切换集火目标**
（打「噬尸蛞蝓（左起1）」2 回合后 → 转打「左起2」）。

## 坑 3：磁盘已有设置文件覆盖默认值

**现象**：改了 `CreateCurrentDefaults()` 但游戏里仍是 120s / `ProgressionFirst`。

**根因**：`SolverSettings.Load()` 先反序列化 `%APPDATA%\SlayTheSpire2\combat_solver_settings.json`，
再 `ApplyCurrentPerformanceMigration(loaded)` —— 磁盘值优先于默认值。

**修复**：`Load()` 里 `ApplyCurrentPerformanceMigration` 之后追加
`migrated = ApplyAutoPilotFusionDefaults(migrated);`。
同时 `SaveLocked` 会被触发（因为 `migrated != loaded`）→ 设置文件被改写。

**实测验证**：`combat_solver_settings.json` 由 **2952B → 2074B**，
`searchTimeLimitSeconds` 120→**60**、`*_boss_hp_strategy` ProgressionFirst→**MinimizeHpLoss**。

## 坑 4：.NET 元数据字符串编码

- `#Strings` 堆（类型/成员名）是 **UTF-8 + NUL 结尾**
  → 搜 `b'get_UiSuppressed'` ✅；搜 utf-16-le ❌
- `#US` 堆（用户可见字面量）是 **UTF-16LE**
  → 搜中文日志/文案串要用 `.encode('utf-16-le')`
- **私有方法名不进元数据** → 无法用字符串搜私有方法，改用反射或日志格式串

## 坑 5：窗口失焦时 PrintWindow 截出全黑

`screenshot.py` 用 `user32.PrintWindow(hwnd, hdc, 2)`。
**窗口失去前台焦点时返回全黑位图**（内容仍正确，只是没渲染）。
解决：截图前先 `SetForegroundWindow(hwnd)` + 短 sleep。

## 坑 6：启动游戏的方式

| 方式 | 结果 |
|---|---|
| `Start-Process 'E:\steam\steam.exe' -ArgumentList '-applaunch 2868840'` | ✅ 有效 |
| `Start-Process 'steam://rungameid/2868840'` | ⚠️ 有时有效（Steam 空闲进程退出时失效） |
| `-ArgumentList '-applaunch','2868840'`（两参数） | ❌ 无效 |
| 直接 `Start-Process 'SlayTheSpire2.exe'` | ❌ 无效 |

判断"是否真的起来了"：轮询 `godot.log` 的 **mtime 变化**（比 `tasklist` 可靠），约 80 秒。

## 环境注意

- 本机 **git-bash 的 PATH 经常丢** → `ls/cat/tail/head/dirname/cp/grep/sleep` 全部 command not found
  → 一切文件/文本/进程操作改用 Python 或 Read/Glob/Grep 工具
- 本机 **PowerShell 工具不回显 stdout** → 需 `Set-Content` 到临时文件再 Read
- 本机 Python `os.remove` 被 shim 劫持成回收站且失败 → 删除文件用 Win32 API 或保留
