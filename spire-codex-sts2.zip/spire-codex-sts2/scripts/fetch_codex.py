# -*- coding: utf-8 -*-
"""下载 spire-codex 原始游戏数据（绕过被墙的 raw.githubusercontent.com，走 GitHub Contents API）。

用法:
    python fetch_codex.py --version v0.111.0 --locale zhs --out ../../rundata/spirecodex
    python fetch_codex.py --list-versions          # 列出仓库里所有可选版本

原理:
    raw.githubusercontent.com 在部分网络下会被重置/502，而 api.github.com 可用。
    Contents API 返回 {content: <base64>}，解出来就是文件原文。
"""
import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request

REPO = 'ptrlrd/spire-codex'
API = f'https://api.github.com/repos/{REPO}/contents'
TREE = f'https://api.github.com/repos/{REPO}/git/trees/main?recursive=1'

# 需要的数据集（缺哪个跳过哪个，不中断）
DATASETS = [
    'cards', 'monsters', 'events', 'relics', 'potions', 'powers', 'encounters',
    'orbs', 'intents', 'keywords', 'characters', 'afflictions', 'enchantments',
    'acts', 'ascensions', 'glossary', 'achievements', 'epochs', 'modifiers',
]

UA = {'User-Agent': 'curl/8', 'Accept': 'application/vnd.github+json'}


def _get(url, timeout=60, retries=3):
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers=UA)
            return urllib.request.urlopen(req, timeout=timeout).read()
        except Exception as e:            # noqa: BLE001 - 网络异常类型多，统一重试
            last = e
            time.sleep(1.0 + i)
    raise last


def list_versions():
    """列出 data-beta/ 下所有版本目录。"""
    raw = _get(TREE, timeout=90)
    tree = json.loads(raw).get('tree', [])
    vers = sorted({p.split('/')[1] for p in (t.get('path', '') for t in tree)
                   if p.startswith('data-beta/') and len(p.split('/')) > 2})
    print(f'仓库 {REPO} 可用版本（data-beta/）:')
    for v in vers:
        print('  ', v)
    return vers


def fetch(version, locale, out):
    os.makedirs(out, exist_ok=True)
    base = f'{API}/data-beta/{version}/{locale}'
    ok, fail = [], []
    for name in DATASETS:
        dst = os.path.join(out, f'{name}.json')
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            print(f'  skip  {name}.json (已存在)')
            ok.append((name, os.path.getsize(dst)))
            continue
        try:
            j = json.loads(_get(f'{base}/{name}.json'))
            raw = base64.b64decode(j['content'])
            with open(dst, 'wb') as f:
                f.write(raw)
            print(f'  OK    {name}.json  {len(raw):,} B')
            ok.append((name, len(raw)))
        except Exception as e:            # noqa: BLE001
            msg = str(e)[:90]
            print(f'  FAIL  {name}.json  {type(e).__name__}: {msg}')
            fail.append((name, type(e).__name__, msg))
    print(f'\n完成：{len(ok)} 个成功 / {len(fail)} 个失败 → {os.path.abspath(out)}')
    if fail:
        print('失败清单（可重跑本脚本补齐）:')
        for n, t, m in fail:
            print(f'  {n}: {t} {m}')
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(description='下载 spire-codex 游戏数据')
    ap.add_argument('--version', default='v0.111.0', help='游戏版本，如 v0.111.0')
    ap.add_argument('--locale', default='zhs', help='语言：zhs/eng/zht/jpn/...')
    ap.add_argument('--out', default='spirecodex', help='输出目录')
    ap.add_argument('--list-versions', action='store_true', help='只列出版本后退出')
    a = ap.parse_args()
    if a.list_versions:
        list_versions()
        return 0
    print(f'下载 {REPO}  {a.version}/{a.locale} → {a.out}')
    return fetch(a.version, a.locale, a.out)


if __name__ == '__main__':
    sys.exit(main())
