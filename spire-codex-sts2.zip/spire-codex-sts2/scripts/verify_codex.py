# -*- coding: utf-8 -*-
"""校验 spire-codex 紧凑知识库的结构完整性 + 抽样打印。

用法:
    python verify_codex.py --kb ../../AutoPilot/kb/sts2_codex.json
    python verify_codex.py --kb ... --cards 595 --monsters 115   # 指定预期条数

校验:
  1. 各数据集条数与预期量级是否相符
  2. cards 每项长度 == 19；monsters 每项 == 8 且 moves 每招 == 5
  3. events 每项 == 5 且 options 每项 == 2；relics 5 / potions 3 / powers 3 / encounters 4
  4. 抽样打印若干条，人眼确认中文无乱码、数值合理
"""
import argparse
import json
import sys

EXPECT = {  # 宽松下限（只报警"明显不对"，不因版本差异误杀）
    'cards': 400, 'monsters': 80, 'events': 40, 'relics': 150,
    'potions': 40, 'powers': 150, 'encounters': 50,
}
LEN = {'cards': 19, 'monsters': 8, 'events': 5, 'relics': 5,
       'potions': 3, 'powers': 3, 'encounters': 4}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--kb', required=True)
    ap.add_argument('--cards', type=int)
    ap.add_argument('--monsters', type=int)
    a = ap.parse_args()

    kb = json.load(open(a.kb, encoding='utf-8'))
    errors = []

    print('=== 1) 条数 ===')
    for sec, low in EXPECT.items():
        n = len(kb.get(sec, {}))
        flag = 'OK ' if n >= low else 'LOW'
        if n < low:
            errors.append(f'{sec} 只有 {n} 条（预期 ≥{low}）')
        print(f'  {flag} {sec:11s} {n}')
    if a.cards is not None and len(kb.get('cards', {})) != a.cards:
        errors.append(f'cards 实际 {len(kb["cards"])} != 预期 {a.cards}')
    if a.monsters is not None and len(kb.get('monsters', {})) != a.monsters:
        errors.append(f'monsters 实际 {len(kb["monsters"])} != 预期 {a.monsters}')

    print('\n=== 2) 字段长度 ===')
    for sec, want in LEN.items():
        bad = [k for k, v in kb.get(sec, {}).items()
               if not isinstance(v, list) or len(v) != want]
        if bad:
            errors.append(f'{sec}: {len(bad)} 项长度 != {want}，样例 {bad[:3]}')
        print(f'  {"OK " if not bad else "BAD"} {sec:11s} 长度异常 {len(bad)}')

    # 嵌套数组
    bad_mv, tot_mv = 0, 0
    for k, v in kb.get('monsters', {}).items():
        if len(v) != 8 or not isinstance(v[6], list):
            continue
        for mv in v[6]:
            tot_mv += 1
            if not isinstance(mv, list) or len(mv) != 5:
                bad_mv += 1
    if bad_mv:
        errors.append(f'monsters.moves 有 {bad_mv} 项 != 5 元')
    print(f'  {"OK " if not bad_mv else "BAD"} moves       共 {tot_mv} 招，异常 {bad_mv}')

    bad_op, tot_op = 0, 0
    for k, v in kb.get('events', {}).items():
        if len(v) != 5 or not isinstance(v[4], list):
            continue
        for op in v[4]:
            tot_op += 1
            if not isinstance(op, list) or len(op) != 2:
                bad_op += 1
    if bad_op:
        errors.append(f'events.options 有 {bad_op} 项 != 2 元')
    print(f'  {"OK " if not bad_op else "BAD"} options     共 {tot_op} 项，异常 {bad_op}')

    print('\n=== 3) 抽样 ===')
    if kb.get('cards'):
        k = next(iter(kb['cards']))
        v = kb['cards'][k]
        print(f'  card   {k}: {v[0]} | {v[1]}费 {v[2]}/{v[3]} | {v[5]}')
    if kb.get('monsters'):
        k = next(iter(kb['monsters']))
        v = kb['monsters'][k]
        print(f'  mon    {k}: {v[0]} [{v[1]}] HP {v[2]}/{v[3]}(进阶 {v[4]}/{v[5]})')
        for mv in (v[6] or [])[:3]:
            print(f'          招 {mv[0]} | {mv[1]} | 伤害 {mv[2]} | 格挡 {mv[3]}')
    if kb.get('events'):
        k = next(iter(kb['events']))
        v = kb['events'][k]
        print(f'  event  {k}: {v[0]} [{v[1]}]')
        for op in (v[4] or [])[:3]:
            print(f'          选项 {op[0]}: {op[1]}')

    print('\n=== 结论 ===')
    if errors:
        print('  ❌ 发现问题:')
        for e in errors:
            print('     -', e)
        return 1
    print('  ✅ 结构完整，无异常')
    return 0


if __name__ == '__main__':
    sys.exit(main())
