# -*- coding: utf-8 -*-
"""把 spire-codex 原始数据编译成紧凑知识库 JSON（数组索引编码，省掉重复键名）。

用法:
    python build_codex.py --src ../../rundata/spirecodex --out ../../AutoPilot/kb/sts2_codex.json

编码（务必与 C# 消费端 Codex.cs 的索引一致）:
    cards      : id -> 19 项数组
    monsters   : id -> 8 项数组（第 6 项为 moves[]，每招 5 项）
    events     : id -> 5 项数组（第 4 项为 options[]，每项 2 项）
    relics     : id -> 5 项
    potions    : id -> 3 项
    powers     : id -> 3 项
    encounters : id -> 4 项
"""
import argparse
import json
import os
import re
import sys

DEFAULT_SRC = 'spirecodex'
DEFAULT_OUT = 'sts2_codex.json'

# 各字段截断长度（避免事件大段描述把体积撑爆）
CLIP = {
    'card_desc': 220,
    'event_desc': 420,
    'relic_desc': 260,
    'potion_desc': 220,
    'power_desc': 220,
    'option_desc': 200,
    'move_desc': 160,
    'notes': 160,
}


def load(src, name):
    p = os.path.join(src, f'{name}.json')
    if not os.path.exists(p):
        print(f'  ! 缺少 {name}.json，跳过')
        return []
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def clip(s, n):
    if not s:
        return None
    s = re.sub(r'\s+', ' ', s).strip()
    return s if len(s) <= n else s[:n - 1] + '…'


def short_vars(v):
    """只保留非 0 数值项。"""
    if not isinstance(v, dict):
        return None
    out = {k: val for k, val in v.items() if isinstance(val, (int, float)) and val != 0}
    return out or None


def fmt_move_damage(dmg):
    """把 {'normal':22,'ascension':26,'hit_count':2} 压成 '22/26x2' 形式。"""
    if isinstance(dmg, dict):
        d = dmg.get('normal')
        asc = dmg.get('ascension')
        hc = dmg.get('hit_count')
        if asc is not None and asc != d:
            d = f'{d}/{asc}'
        if hc:
            d = f'{d}x{hc}' if d is not None else f'x{hc}'
        return d
    if isinstance(dmg, (int, float)):
        return dmg
    return None


def build(src, out, version='v0.111.0', locale='zhs'):
    print('读取 spire-codex 数据…')
    cards = load(src, 'cards')
    monsters = load(src, 'monsters')
    events = load(src, 'events')
    relics = load(src, 'relics')
    potions = load(src, 'potions')
    powers = load(src, 'powers')
    encounters = load(src, 'encounters')

    o = {
        'meta': {
            'source': 'ptrlrd/spire-codex',
            'game_version': version,
            'locale': locale,
            'note': 'spire-codex 反编译数据；卡牌/怪物/事件的权威描述与数值。回答"这是什么"；对局统计知识库回答"这好不好"。',
        },
        'cards': {}, 'monsters': {}, 'events': {}, 'relics': {},
        'potions': {}, 'powers': {}, 'encounters': {},
    }

    for c in cards:
        cid = c.get('id')
        if not cid:
            continue
        o['cards'][cid] = [
            c.get('name') or cid, c.get('cost'), c.get('type'), c.get('rarity'), c.get('color'),
            clip(c.get('description'), CLIP['card_desc']),
            clip(c.get('upgrade_description'), CLIP['card_desc']),
            short_vars(c.get('vars')), c.get('keywords'), c.get('tags'),
            c.get('hit_count'), c.get('cards_draw'), c.get('energy_gain'), c.get('target'),
            c.get('upgrade'), c.get('powers_applied'), c.get('spawns_cards'),
            bool(c.get('is_x_cost')), bool(c.get('multiplayer_only')),
        ]

    for m in monsters:
        mid = m.get('id')
        if not mid:
            continue
        moves = []
        for mv in (m.get('moves') or []):
            moves.append([
                mv.get('name'), mv.get('intent'), fmt_move_damage(mv.get('damage')),
                mv.get('block'), clip(mv.get('description'), CLIP['move_desc']),
            ])
        o['monsters'][mid] = [
            m.get('name') or mid, m.get('type'),
            m.get('min_hp'), m.get('max_hp'),
            m.get('min_hp_ascension'), m.get('max_hp_ascension'),
            moves, clip(m.get('notes'), CLIP['notes']),
        ]

    for e in events:
        eid = e.get('id')
        if not eid:
            continue
        opts = [[x.get('title'), clip(x.get('description'), CLIP['option_desc'])]
                for x in (e.get('options') or [])]
        o['events'][eid] = [
            e.get('name') or eid, e.get('act'), e.get('type'),
            clip(e.get('description'), CLIP['event_desc']), opts,
        ]

    for r in relics:
        rid = r.get('id')
        if rid:
            o['relics'][rid] = [r.get('name') or rid, r.get('rarity'),
                                clip(r.get('description'), CLIP['relic_desc']),
                                r.get('merchant_price'), r.get('pool')]

    for p in potions:
        pid = p.get('id')
        if pid:
            o['potions'][pid] = [p.get('name') or pid, p.get('rarity'),
                                 clip(p.get('description'), CLIP['potion_desc'])]

    for pw in powers:
        pid = pw.get('id')
        if pid:
            o['powers'][pid] = [pw.get('name') or pid, pw.get('type'),
                                clip(pw.get('description'), CLIP['power_desc'])]

    for en in encounters:
        eid = en.get('id')
        if eid:
            o['encounters'][eid] = [en.get('name') or eid, en.get('room_type'), en.get('act'),
                                    [x.get('id') for x in (en.get('monsters') or [])]]

    d = os.path.dirname(os.path.abspath(out))
    if d:
        os.makedirs(d, exist_ok=True)
    js = json.dumps(o, ensure_ascii=False, separators=(',', ':'))
    with open(out, 'w', encoding='utf-8') as f:
        f.write(js)

    raw_total = sum(os.path.getsize(os.path.join(src, f'{n}.json'))
                    for n in ('cards', 'monsters', 'events', 'relics', 'potions', 'powers', 'encounters')
                    if os.path.exists(os.path.join(src, f'{n}.json')))
    print(f'\n输出 {os.path.abspath(out)}')
    print(f'  体积  {len(js.encode("utf-8")):>10,} B   （原始 7 表 {raw_total:,} B，压缩 '
          f'{raw_total / max(1, len(js.encode("utf-8"))):.1f}×）')
    for k in ('cards', 'monsters', 'events', 'relics', 'potions', 'powers', 'encounters'):
        print(f'  {k:11s} {len(o[k])}')
    return o


def main():
    ap = argparse.ArgumentParser(description='编译 spire-codex 数据为紧凑知识库')
    ap.add_argument('--src', default=DEFAULT_SRC)
    ap.add_argument('--out', default=DEFAULT_OUT)
    ap.add_argument('--version', default='v0.111.0')
    ap.add_argument('--locale', default='zhs')
    a = ap.parse_args()
    o = build(a.src, a.out, a.version, a.locale)
    return 0 if len(o['cards']) else 1


if __name__ == '__main__':
    sys.exit(main())
