---
name: spire-codex-sts2
description: 把 ptrlrd/spire-codex 的《杀戮尖塔2》反编译游戏数据（卡牌/怪物招式/事件选项/遗物/药水/能力/遭遇，含中文）下载并编译成紧凑知识库，供 StS2 mod 或 AI 决策程序使用。当需要在杀戮尖塔2模组里接入权威游戏数值、做战损计算、事件房决策、选牌评分，或需要 StS2 卡牌/怪物/事件的结构化数据时使用。也适用于任何"从 GitHub 仓库拉取大量 JSON 数据但 raw.githubusercontent.com 被墙"的场景。
agent_created: true
---

# spire-codex → 杀戮尖塔2 知识库

## 用途

`ptrlrd/spire-codex`（287★，TypeScript）把《杀戮尖塔2》(Slay the Spire 2) 反编译成了结构化 JSON API。
本技能提供**下载 + 压缩编译 + C# 消费端**的完整流水线，把 1.4MB 原始数据变成 ~330KB 可直接随 mod 分发的知识库。

分工原则（重要）：

| 数据 | 回答的问题 | 本机对应 |
|---|---|---|
| **spire-codex**（本技能产出） | 「这牌/怪/事件**是什么**」——官方描述与精确数值 | `Codex.cs` + `kb/sts2_codex.json` |
| 真实对局统计（另有一套流水线） | 「这牌**好不好**」——价值/选择率/协同 | `RunStats.cs` + `kb/sts2_kb.json` |

两者互补，**不要混用**：spire-codex 是权威静态数据，不含任何玩家统计。

## 关键坑（先读这两条，能省一小时）

### ① raw.githubusercontent.com 被墙 → 用 GitHub Contents API

`https://raw.githubusercontent.com/...` 会返回 `RemoteDisconnected` / `502 Bad Gateway`。
**改用 Contents API 并且 `base64.b64decode`**：

```
https://api.github.com/repos/ptrlrd/spire-codex/contents/data-beta/v0.111.0/zhs/cards.json
```

请求头 `User-Agent: curl/8` + `Accept: application/vnd.github+json`，
响应 JSON 的 `content` 字段是 base64 编码的文件体。

单次 API 请求可拉几百 KB；文件多时**逐个串行拉取**并加 try/except（部分文件偶发 502，重试即可）。
推荐先拉 `git/trees/main?recursive=1` 拿到完整文件清单（该接口稳定、约 27k 条路径），再按需下载。

### ② 版本目录必须与游戏版本对齐

仓库路径形如 `data-beta/<版本>/<locale>/<数据集>.json`：

- `data-beta/v0.111.0/zhs/` ← 中文（`zhs`）；另有 `eng` / `zht` / `jpn` 等 15 种语言
- 先确认游戏版本（`sts2.dll` 的文件版本 / 模组 manifest 里的 `min_game_version`），**不要随手用 `data/` 根目录**（那是最新开发版，可能超前于线上游戏）

## 流水线

### 步骤 1：下载原始数据

```bash
python scripts/fetch_codex.py --version v0.111.0 --locale zhs --out ../../rundata/spirecodex
```

脚本会拉取以下数据集（缺哪个跳过哪个，不中断）：

`cards` `monsters` `events` `relics` `potions` `powers` `encounters` `orbs` `intents` `keywords` `characters` `afflictions` `enchantments` `acts` `ascensions` `glossary` `achievements` `epochs` `modifiers`

### 步骤 2：编译成紧凑知识库

```bash
python scripts/build_codex.py --src ../../rundata/spirecodex --out ../../AutoPilot/kb/sts2_codex.json
```

用**数组索引编码**（而非对象键名）压缩，省掉重复键名导致的一倍体积：

```
cards      : id -> [名称, 费用, 类型, 稀有度, 职业, 描述, 升级描述, vars, 关键词, 标签, 段数, 抽牌, 得能量, 目标, 升级增量, 施加状态, 生成卡, X费, 联机限定]   (19 项)
monsters   : id -> [名称, 类型, minHp, maxHp, minHpAsc, maxHpAsc, moves[], notes]                                                                                (8 项)
             moves[i] = [招名, 意图, 伤害("22" / "22/26" / "11x2"), 格挡, 说明]                                                                                   (5 项)
events     : id -> [名称, 幕, 类型, 描述, options[]]                                                                                                            (5 项)
             options[i] = [标题, 说明]                                                                                                                          (2 项)
relics     : id -> [名称, 稀有度, 描述, 商店价, 池]        (5 项)
potions    : id -> [名称, 稀有度, 描述]                    (3 项)
powers     : id -> [名称, 类型, 描述]                      (3 项)
encounters : id -> [名称, 房间类型, 幕, 怪物 ids]          (4 项)
```

压缩效果：1.4MB → ~332KB（4.2×），595 卡 / 115 怪（345 招）/ 66 事件（143 选项）全部保留。
长文本按字段截断（事件描述 420 字、卡牌描述 220 字），`vars` 里值为 0 的项丢弃。

### 步骤 3：接入消费端

C# 消费端参考实现已内置于 `references/Codex.cs`，直接拷进 mod 工程即可。要点：

1. **`JsonElement.Clone()` 是必须的** —— `JsonDocument` 一旦释放（`using` 结束），其所有 `JsonElement` 立即失效。必须逐条 `Clone()` 后存进 `Dictionary<string, JsonElement>`。
2. id 归一化要处理三种形态：`STS2.BASH`（带命名空间前缀）、`BASH+`（升级后缀）→ 去前缀、去 `+`、转大写。
3. 加载时机：惰性（首次查询时 `EnsureLoaded()`），失败只记日志不抛异常——**知识库是锦上添花，绝不能让 mod 因此崩**。
4. 路径解析按顺序试：`<dll目录>/kb/sts2_codex.json` → `<dll目录>/sts2_codex.json` → `mods/<ModId>/kb/sts2_codex.json`。

### 步骤 4：把数据喂给 LLM / 决策逻辑

最有价值的三处接入点：

| 接入点 | 用哪些数据 | 效果 |
|---|---|---|
| **战斗提示词** | `monsters` 的 `moves[]`（含 `22` / `22/26` / `11x2` 形式的伤害） | 给出敌人**完整招式表与伤害上限**，补上"意图 API 只给当前招"的盲区 |
| **事件房提示词** | `events.options[]` | 给出该事件**全部选项的官方文本**，杜绝模型凭记忆编 |
| **卡牌奖励提示词** | `cards` 的描述 + `upgrade_description` | 卡牌**官方效果与升级增益**，配合对局统计判断"好不好" |

事件 id 的获取（C#）：`NEventOptionButton.Event.Id.Entry`（事件 id）+ `NEventOptionButton.Option.TextKey`（选项 id）。

## 校验

编译后**务必跑结构校验**（字段数、类型、抽样内容）：

```bash
python scripts/verify_codex.py --kb ../../AutoPilot/kb/sts2_codex.json
```

校验项：每张卡的数组长度是否等于 19、怪物 moves 是否为 5 元数组、事件 options 是否为 2 元数组、
各数据集条数是否与预期量级相符、抽样打印若干条可读结果（用于人眼确认中文没乱码）。

## 部署提醒

知识库文件必须随 mod 一起部署到 `mods/<ModId>/kb/`。若 mod 有部署脚本，**记得把 kb 目录一并纳入**
（并 `makedirs`），否则 mod 能跑但所有权威数据查询静默返回 null。

## 资源

- `scripts/fetch_codex.py` —— 下载原始数据（走 Contents API，绕开被墙的 raw 域名）
- `scripts/build_codex.py` —— 压缩编译成紧凑知识库
- `scripts/verify_codex.py` —— 结构校验 + 抽样打印
- `references/Codex.cs` —— C# 消费端完整参考实现（可直接拷入 mod）
